import os
import json
from aiogram import Bot, Dispatcher, executor, types
import requests
import random
from aiogram.types import InputFile
import sqlite3


API_TOKEN = '6130636744:AAHlU7IR_DlGpjUTP_XleP-9dSjLwhCemNc'
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

conn = sqlite3.connect('GymBD.db')
cur = conn.cursor()

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    markup = types.ReplyKeyboardMarkup()
    buttonA = types.KeyboardButton('🏃‍♂️ Кардио')
    buttonB = types.KeyboardButton('💪 Сильные руки')
    buttonD = types.KeyboardButton('🏋️‍♀️ Подтянутые ягодицы')
    buttonE = types.KeyboardButton('🧘‍♀️ Идеальная талия')
    buttonF = types.KeyboardButton('🙆‍♀️ Разминка на стуле')
    buttonS = types.KeyboardButton('🤸‍♀️ Здоровая спина')
    buttonP = types.KeyboardButton('🥑 Советы по питанию')
    markup.row(buttonA, buttonB)
    markup.row(buttonE, buttonD)
    markup.row(buttonF, buttonS)
    markup.row(buttonP)
    await message.reply('Выбери категорию упражнения, чтобы продолжить ', reply_markup=markup)



@dp.message_handler(commands=['help'])
async def welcome_help(message: types.Message):
    await message.reply('')


@dp.message_handler(content_types=["text"])
async def text(message):
    if message.text == '🏃‍♂️ Кардио':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '1'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == '💪 Сильные руки':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '4'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == '🤸‍♀️ Здоровая спина':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '2'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == '🏋️‍♀️ Подтянутые ягодицы':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '3'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == '🙆‍♀️ Разминка на стуле':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '6'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == '🧘‍♀️ Идеальная талия':
        cur.execute("SELECT name, pic, description FROM gym WHERE category = '5'")
        finds = cur.fetchall()
        name, pic, description = random.choice(finds)
        text = f'УПРАЖНЕНИЕ: {name} \n{description}'
        text1 = f'{pic}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)

    elif message.text == "🥑 Советы по питанию":
        cur.execute("SELECT pic, description FROM gym WHERE category = '7'")
        finds = cur.fetchall()
        pic, description = random.choice(finds)
        text1 = f'{pic}'
        text =f'{description}'
        await bot.send_photo(message.chat.id, InputFile(text1))
        await bot.send_message(message.chat.id, text)



    #if message.text == 'Сильные руки':
    #    img = open('hands/' + random.choice(os.listdir('hands')), 'rb')
    #    await bot.send_video(message.chat.id, img, None)
    #    img.close()


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)